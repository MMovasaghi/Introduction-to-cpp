First DO ALL thing on part1 
then CLOSE your Visual Studio Application
then OPEN this project it will be Done.