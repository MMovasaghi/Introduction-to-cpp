#include <iostream>
using namespace std;

int main()
{
	int number1 = 0;
	int number2 = 0;
	
	cout << "Please Enter 2 Number : \n - Number1 : ";
	cin >> number1;
	cout << "\n - Number1 : ";
	cin >> number2;
	
	if(number1 < number2)
		cout << "\n\n Result : " << number1 << " < " << number2 <<endl;
	if(number1 == number2)
		cout << "\n\n Result : " << number1 << " = " << number2 <<endl;
	if(number1 > number2)
		cout << "\n\n Result : " << number1 << " > " << number2 <<endl;
	
	return 0;
}
