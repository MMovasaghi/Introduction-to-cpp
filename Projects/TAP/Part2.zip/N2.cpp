#include <iostream>
#include <string>
using namespace std;

class Compare
{
	public :
		Compare(double a, double b)
		{
			n1 = a;
			n2 = b;
		}
		void Cal()
		{
			if(n1 < n2)
				cout << "\n\n Result : " << n1 << " < " << n2 <<endl;
			if(n1 == n2)
				cout << "\n\n Result : " << n1 << " = " << n2 <<endl;
			if(n1 > n2)
				cout << "\n\n Result : " << n1 << " > " << n2 <<endl;
		}
	private :
		double n1,n2;	
};

int main()
{
	double number1 = 0;
	double number2 = 0;
	
	cout << "Please Enter 2 Number : \n - Number1 : ";
	cin >> number1;
	cout << "\n - Number1 : ";
	cin >> number2;
	
	Compare c(number1,number2);
	
	c.Cal();
	
	
	return 0;
}
