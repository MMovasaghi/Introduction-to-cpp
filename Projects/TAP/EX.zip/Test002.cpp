#include <iostream>
using namespace std;
int main()
{
	int a = 10;
	if(a = 20)
	{
		cout << "N";
	}
	else
	{
		cout << "B";
	}
	return 0;
}
