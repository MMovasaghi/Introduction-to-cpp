#include <iostream>
#include <string>
using namespace std;
class Test
{
	public :
//		void DM()
//		{
//			
//		}
//		int DM()
//		{
//			
//		}
//		double DM()
//		{
//			
//		}
//		bool DM()
//		{
//			
//		}
//		float DM()
//		{
//			
//		}
//		string DM()
//		{
//			
//		}	
};


int main()
{
	double a = (double)7/3;
	int b = 7/3;
	double c = 7/3;
	cout << "\ndouble a = (double)7/3 : " << a;
	cout << "\nint b = 7/3 : " << b;
	cout << "\ndouble c = 7/3 : " << c;
	return 0;
}
