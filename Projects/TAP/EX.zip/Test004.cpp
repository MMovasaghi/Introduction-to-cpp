#include <iostream>
#include <string>
using namespace std;
class Test
{
	public :
		void DM1()
		{
			cout << "Function Name : (DM1)  : " << "CP 97" << endl;			
		}
		bool IsMorethan10(int a)
		{
			if(a > 10)
			{
				return 1;
			}
			else 
			{
				return 0;
			}
		}
	private :
		void DM2()
		{
			cout << "Function Name : (DM2)  : " << "CP 97" << endl;
		}			
};


int main()
{
	Test t1;
	Test t2;
	t1.DM1();
	int b;
	cout << "Enter A Number : ";
	cin >> b;
	if(!t1.IsMorethan10(b))
		cout << "\n\nEnterd Number is More than 10";
	else
		cout << "\n\nNo";
	return 0;
}
