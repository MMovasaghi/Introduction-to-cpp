#include <iostream>
using namespace std;
int main()
{
	cout << "Hello world!\tHi\r" ;
	cout << "Salam";
	cout << "IURTTFSDFSD";
	return 0;
}
