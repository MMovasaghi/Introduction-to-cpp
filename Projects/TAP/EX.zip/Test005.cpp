#include <iostream>
#include <string>
#include <cmath>
using namespace std;
class Test
{
	public :
		void DM1()
		{
			cout << "Function Name : (DM1)  : " << "CP 97" << endl;			
		}
		bool IsMorethan10(int a)
		{
			if(a > 10)
			{
				return 1;
			}
			else 
			{
				return 0;
			}
		}
		void CallIsAval()
		{
			int b;
			cout << "Enter A Number : ";
			cin >> b;
			bool a = IsAval(b);
			cout << "\n\nResult : " << boolalpha << a;
		}
		
		
	private :
		void DM2()
		{
			cout << "Function Name : (DM2)  : " << "CP 97" << endl;
		}
		bool IsAval(int a)
		{
			if(a >= 2)
			{
				for(int i = 2; i <= sqrt(a) ; i++)
				{
					if(a%i == 0)
						return false;
				}
				
				return true;
			}
			return false;
		}			
};


int main()
{
	Test t1;
	Test t2;
	t1.DM1();
	t1.CallIsAval();
	
	return 0;
}
